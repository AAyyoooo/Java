
package javafxstart;

import javafx.application.Application;
import javafx.stage.Stage;


public class Javafxstart extends Application {
    
    
    
    @Override
    public void start(Stage stage) throws Exception {
       // stage.setTitle("hhello");
        stage.show();
        stage.setTitle("hello bro");
        
    }
    

    
    public static void main(String[] args) {
        
        launch(args);
        
    }

    
    }
    

