
package discount;


public class Discount {

    
    
  static  double discount(int ...p)
    
    { int s=0;
    for(int i=0;i<p.length;i++)
   s=s+p[i];
    {if(s<500)
       return  10%
               { if(s>500&&s<1000)
  return  15%
          {  if(s>1000)
   return 20%
                      }
     
    } 
  
    
    public static void main(String[] args) {
    
        
    }
    
}
