
package array1;



public class Array1 {

    
    public static void main(String[] args) {
    
   String arr[]={ "Ayush","z", "Mummy","Ppap"};
   java.util.Arrays.sort(arr);
    for(String x:arr)
        System.out.println(x);
    
    }}

   
