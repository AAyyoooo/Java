
package javaapplication12;

public class JavaApplication12 {

  boolean validate(String name)
  {
      return name.matches("[A-Za-z\\s]*");
      
  }
   boolean validate(int age)
   { return age>=3 && age<=15;}
       public static void main(String[] args) {
        
validate(aush yy);
   
    }
  
    
}
