
package oddneven;
import java.util.Scanner;

/**
 *
 * @author 91708
 */
public class Oddneven {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
   
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    {if(n%2==0){
       System.out.println("evenbanda");
    }
    else
        System.out.println("oddbandi");}
    
    }
    
}
