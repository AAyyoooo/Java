/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package age.young.old;
import java.util.Scanner;
/**
 *
 * @author 91708
 */
public class AgeYoungOld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
int n;
Scanner sc=new Scanner(System.in);
n=sc.nextInt();
{
    if(n>=18 &&n<100){
        System.out.println("adult");
             }
    
        else
        System.out.println("nibba");
}
    }
    
}
