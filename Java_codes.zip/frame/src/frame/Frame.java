
package frame;
import java.util.*;

public class Frame {

   
    public static void main(String[] args) {
        
        Framee f=new Framee("My first app");
        f.setVisible(true);
    }
    
}
