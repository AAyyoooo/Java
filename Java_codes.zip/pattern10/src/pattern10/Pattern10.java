/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pattern10;

/**
 *
 * @author 91708
 */
public class Pattern10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        for(int i=1;i<=5;i++)
    {
        for(int j=1;j<=9;j++)
    {   
       if(i+j==6) 
        System.out.print("*");
    
        else
     System.out.println("");
    
    }
       
    
    
    } 
        
        System.out.println(" ");
    }
    
    }


//  this question isn't coming ..?
//				*	
//			*	*	*			
//		*	*	*	*	*		
//	*	*	*	*	*	*	*	
//*	*	*	*	*	*	*	*	*



