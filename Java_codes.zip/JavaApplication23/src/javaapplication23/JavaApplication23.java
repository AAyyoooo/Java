
package javaapplication23;

class subject
{ private String subID;
private String name ;
private short maxmark;


public subject(String subID, String name, short maxmark)
{ maxmark=80;}


public String getSubID()
{ return subID; }
public String getName()
{ return name;}
public Short getMaxMark()
{ return maxmark;}

public void setMaxMark(short maxmark )
{ this.maxmark=maxmark;}





}




public class JavaApplication23 {

    
    public static void main(String[] args) {
       
    }
    
}
